import javax.swing.*;
import java.awt.*;
import static java.lang.StrictMath.pow;
public class Inicjaly extends JPanel {
    @Override
    public void paintComponent(Graphics g) {
        super.paintComponent(g);
        Graphics2D g2 = (Graphics2D) g;
        setBackground(Color.yellow);
        Font font = new Font("Serif", Font.PLAIN, 20);
        g2.setFont(font);
        g2.drawString("Mateusz Żero gr Lab 5 82727", 370, 500);
        //Litera M
        double Ax, Ay;
        double[] x = {72,79,79,55,55,51,51,36,36,9,9,7,7,6,6,12,12,27,27,40,40,61,61,79,79,92,92,102,102,104,104,106,106,149,149,147,147,129,129,180,180,165,165,125,
                125,301,301,233,233,182,182,215,215,214,214,214,214,216,216,272,272,287,287,312,312,277,277,265,265,216,216,217};
        double[] y = {273,264,264,255,255,254,254,250,250,263,263,295,295,310,310,350,350,358,358,365,365,376,376,363,363,354,354,341,341,326,326,311,
                311,90,90,105,105,265,265,323,323,321,321,316,316,104,104,65,65,36,36,280,280,323,323,338,338,369,369,371,371,372,372,363,363,338,338,329,329,319,319,340};
        //Litera Ż
        double Bx, By;
        double[] x1 = {349,347,347,328,328,377,377,392,392,499,499,526,526,545,545,585,585,515,515,
                503,503,389,389,376,376,364,364,278,278,369,369,386,386,517,517,545,545,560,560,606,606,528};
        double[] y1 = {150,165,165,126,126,115,115,112,112,150,150,153,153,155,155,65,65,129,129,140,
                140,349,349,359,359,368,368,344,344,323,323,319,319,360,360,366,366,369,369,273,273,346};
        //Falka przy Z
        double Cx, Cy;
        double[] x2 = {400, 401, 512, 512};
        double[] y2 = {246, 187, 307, 246};
        //Kropka nad Ż
        double Dx, Dy;
        double[] x3 = {459,436,436,414,414,436,436,452,452,479,479,459};
        double[] y3 = {32,21,21,44,44,60,60,72,72,53,53,32};
        g2.setColor(Color.ORANGE);
        g2.setStroke(new BasicStroke(5f,
                BasicStroke.CAP_SQUARE,
                BasicStroke.JOIN_MITER,
                10));
        for(int i = 0; i <= 17; i++) {
            for(double t = 0; t <=1; t=t+0.001) {
                Ax = pow(1-t,3) * x[4*i] + 3 * pow(1-t,2) * t * x[4*i+1] + 3 * (1-t) * pow(t,2) * x[4*i+2] + pow(t,3) * x[4*i+3];
                Ay = pow(1-t,3) * y[4*i] + 3 * pow(1-t,2) * t * y[4*i+1] + 3 * (1-t) * pow(t,2) * y[4*i+2] + pow(t,3) * y[4*i+3];
                g2.drawLine((int)Ax,(int)Ay, (int)Ax, (int)Ay);
            } }
        for(int i = 0; i <= 9; i++) {
            for(double t = 0; t <=1; t=t+0.001) {
                Bx = pow(1-t,3) * x1[4*i] + 3 * pow(1-t,2) * t * x1[4*i+1] + 3 * (1-t) * pow(t,2) * x1[4*i+2] + pow(t,3) * x1[4*i+3];
                By = pow(1-t,3) * y1[4*i] + 3 * pow(1-t,2) * t * y1[4*i+1] + 3 * (1-t) * pow(t,2) * y1[4*i+2] + pow(t,3) * y1[4*i+3];
                g2.drawLine((int)Bx,(int)By, (int)Bx, (int)By);
            } }
        for(int i = 0; i <= 0; i++) {
            for(double t = 0; t <=1; t=t+0.001) {
                Bx = pow(1-t,3) * x2[4*i] + 3 * pow(1-t,2) * t * x2[4*i+1] + 3 * (1-t) * pow(t,2) * x2[4*i+2] + pow(t,3) * x2[4*i+3];
                By = pow(1-t,3) * y2[4*i] + 3 * pow(1-t,2) * t * y2[4*i+1] + 3 * (1-t) * pow(t,2) * y2[4*i+2] + pow(t,3) * y2[4*i+3];
                g2.drawLine((int)Bx,(int)By, (int)Bx, (int)By);
            } }
        for(int i = 0; i <= 2; i++) {
            for(double t = 0; t <=1; t=t+0.001) {
                Bx = pow(1-t,3) * x3[4*i] + 3 * pow(1-t,2) * t * x3[4*i+1] + 3 * (1-t) * pow(t,2) * x3[4*i+2] + pow(t,3) * x3[4*i+3];
                By = pow(1-t,3) * y3[4*i] + 3 * pow(1-t,2) * t * y3[4*i+1] + 3 * (1-t) * pow(t,2) * y3[4*i+2] + pow(t,3) * y3[4*i+3];
                g2.drawLine((int)Bx,(int)By, (int)Bx, (int)By);
            } }
    }
}