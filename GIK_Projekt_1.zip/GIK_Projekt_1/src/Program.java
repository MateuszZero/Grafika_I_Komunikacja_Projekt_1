import javax.swing.*;
import java.awt.*;
import java.io.IOException;
import java.awt.event.*;

public class Program{

    private static int wybor = 0;
    public static void main(String[] args) {
        JFrame f = new JFrame();
        f.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

        JButton b1 = new JButton("OBRAZEK");
        b1.setBounds(80, 100, 220, 40);
        JButton b2 = new JButton("INSTRUKCJA DO GRY");
        b2.setBounds(80, 150, 220, 40);
        JButton b3 = new JButton("INICJALY");
        b3.setBounds(80, 200, 220, 40);
        JButton b4 = new JButton("GENERUJ BEZIERA3D DO PLIKU*");
        b4.setBounds(80, 250, 220, 40);

        JLabel l1, l2, l3;
        l1 = new JLabel("GiK - Program 1");
        Font font = new Font("Serif", Font.PLAIN, 50);
        Font font2 = new Font("Serif", Font.PLAIN, 15);
        l1.setFont(font);
        l1.setBounds(20, 20, 600, 60);
        l2 = new JLabel("Mateusz Żero gr Lab 5 82727");
        l2.setBounds(200, 320, 200, 30);
        l2.setFont(font2);
        l3 = new JLabel("*Uwaga: ladowanie punktow moze chwile potrwac");
        l3.setBounds(50, 285, 300, 30);
        f.add(l1);
        f.add(l2);
        f.add(l3);

        f.add(b1);
        f.add(b2);
        f.add(b3);
        f.add(b4);

        f.setSize(400, 400);
        f.setLayout(null);
        f.setVisible(true);

        b1.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                EventQueue.invokeLater(new Runnable() {
                    @Override
                    public void run() {
                        Rysunek ex = new Rysunek();
                        ex.setResizable(false);
                        ex.setVisible(true);
                    }});}
        });
        b2.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {

                JOptionPane.showMessageDialog(f,
                        "Gre nalezy uruchomic z sasiedniego folderu lub oddzielnie z klasy z powodu wyjatku");
            }
        });
        b3.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                InicjalyOkno o = new InicjalyOkno();
            }
        });
        b4.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                try {
                    new Dzbanek();
                } catch (IOException ex) {
                    ex.printStackTrace();
                }
                JOptionPane.showMessageDialog(f,
                        "Pomyslnie wygenerowano punkty dzbanka, filizanki oraz lyzeczki do folderu 'WspolrzedneDoModelu3D'.");
                b4.setText("GENERUJ BEZIERA3D DO PLIKU");
            }

        });
    }
}