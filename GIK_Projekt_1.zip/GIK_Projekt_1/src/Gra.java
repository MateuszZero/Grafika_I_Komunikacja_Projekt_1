import java.awt.*;
import javax.swing.*;
import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;
import java.io.IOException;

public class Gra extends JPanel{
    int skrzyzowanie_x, skrzyzowanie_y;
    int samochod_x, samochod_y;
    int predkosc_x, predkosc_y;
    int nr_przeciwnikow;
    String przeciwnicy_png[];
    int px[], py[];
    int wynik;
    int rekord;
    int predkosc_przeciw[];
    boolean koniec_gry;
    boolean Gora, Dol, Prawo, Lewo;
    public Gra(){
        skrzyzowanie_x = skrzyzowanie_y = -999;
        addKeyListener(new KeyListener() {
            public void keyTyped(KeyEvent e) {}
            public void keyReleased(KeyEvent e) {
                stopCar(e);}
            public void keyPressed(KeyEvent e) {
                moveCar(e);}
        });
        setFocusable(true);
        samochod_x = 75;
        samochod_y = 220;
        Gora = Dol = Lewo = Prawo = false;
        predkosc_x = predkosc_y = 0;
        nr_przeciwnikow = 0;
        px = new int[20];
        py = new int[20];
        przeciwnicy_png = new String[20];
        predkosc_przeciw = new int[20];
        koniec_gry = false;
        wynik = rekord = 0;}
    public void paint(Graphics g){
        super.paint(g);
        Graphics2D obj = (Graphics2D) g;
        obj.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
        try{
            obj.drawImage(getToolkit().getImage("images/droga.png"), skrzyzowanie_x -499, skrzyzowanie_y -2 ,this);
            obj.drawImage(getToolkit().getImage("images/droga.png"), skrzyzowanie_x +499, skrzyzowanie_y -2 ,this);
            if(skrzyzowanie_y >= -499 && skrzyzowanie_x >= -499)
                obj.drawImage(getToolkit().getImage("images/skrzyzowanie.png"), skrzyzowanie_x, skrzyzowanie_y,this);
            obj.drawImage(getToolkit().getImage("images/gracz.png"), samochod_x, samochod_y,this);
            if(koniec_gry){
                obj.drawImage(getToolkit().getImage("images/boom.png"), samochod_x -30, samochod_y -30,this);
            }
            if(this.nr_przeciwnikow > 0){
                for(int i = 0; i<this.nr_przeciwnikow; i++){
                    obj.drawImage(getToolkit().getImage(this.przeciwnicy_png[i]),this.px[i],this.py[i],this);}}
        }
        catch(Exception e){
            System.out.println(e);}
    }
    void moveRoad(int count){
        if(skrzyzowanie_x == -999 && skrzyzowanie_y == -999){
            if(count%10 == 0){
                skrzyzowanie_x = 499;
                skrzyzowanie_y = 0;}}
        else{skrzyzowanie_x--;}
        if(skrzyzowanie_x == -499 && skrzyzowanie_y == 0){
            skrzyzowanie_x = skrzyzowanie_y = -999;}
        samochod_x += predkosc_x;
        samochod_y += predkosc_y;
        if(samochod_x < 0)
            samochod_x = 0;
        if(samochod_x +93 >= 500)
            samochod_x = 500-93;
        if(samochod_y <= 124)
            samochod_y = 124;
        if(samochod_y >= 364-50)
            samochod_y = 364-50;
        for(int i = 0; i<this.nr_przeciwnikow; i++){
            this.px[i] -= predkosc_przeciw[i];
        }
        int index[] = new int[nr_przeciwnikow];
        for(int i = 0; i< nr_przeciwnikow; i++){
            if(px[i] >= -127){
                index[i] = 1;
            }}
        int c = 0;
        for(int i = 0; i< nr_przeciwnikow; i++){
            if(index[i] == 1){
                przeciwnicy_png[c] = przeciwnicy_png[i];
                px[c] = px[i];
                py[c] = py[i];
                predkosc_przeciw[c] = predkosc_przeciw[i];
                c++;
            }}
        wynik += nr_przeciwnikow - c;
        if(wynik > rekord)
            rekord = wynik;
        nr_przeciwnikow = c;
        int diff = 0;
        for(int i = 0; i< nr_przeciwnikow; i++){
            diff = samochod_y - py[i];
            if((py[i] >= samochod_y && py[i] <= samochod_y +46) || (py[i]+46 >= samochod_y && py[i]+46 <= samochod_y +46)){
                if(samochod_x +87 >= px[i] && !(samochod_x >= px[i]+87)){
                    System.out.println("Twoje auto : "+ samochod_x +", "+ samochod_y);
                    System.out.println("Zderzylo sie w : "+ px[i]+", "+ py[i]);
                    this.finish();
                }}}
    }
    void finish(){
        String str = "";
        koniec_gry = true;
        this.repaint();
        if(wynik == rekord && wynik != 0)
            str = "\nGratulacje!!! Nowy Rekord!";
        JOptionPane.showMessageDialog(this,"Koniec Gry!!!\nTwoj Wynik : "+ wynik +"\nRekord : "+ rekord +str,     "Koniec Gry", JOptionPane.YES_NO_OPTION);
        System.exit(ABORT);
    }
    public void moveCar(KeyEvent e){
        if(e.getKeyCode() == KeyEvent.VK_RIGHT){
            Gora = true;
            predkosc_x = 1;}
        if(e.getKeyCode() == KeyEvent.VK_LEFT){
            Dol = true;
            predkosc_x = -2;}
        if(e.getKeyCode() == KeyEvent.VK_DOWN){
            Prawo = true;
            predkosc_y = 2;}
        if(e.getKeyCode() == KeyEvent.VK_UP){
            Lewo = true;
            predkosc_y = -2;}
    }
    public void stopCar(KeyEvent e){
        if(e.getKeyCode() == KeyEvent.VK_RIGHT){
            Gora = false;
            predkosc_x = 0;}
        else if(e.getKeyCode() == KeyEvent.VK_LEFT){
            Dol = false;
            predkosc_x = 0;}
        else if(e.getKeyCode() == KeyEvent.VK_DOWN){
            Lewo = false;
            predkosc_y = 0;}
        else if(e.getKeyCode() == KeyEvent.VK_UP){
            Prawo = false;
            predkosc_y = 0;}
    }
    public static void main(String args[]) throws IOException {
        JFrame frame = new JFrame("Wyscig!");
        Gra gra = new Gra();
        frame.add(gra);
        frame.setSize(500,500);
        frame.setVisible(true);
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setResizable(false);
        int count = 1, c = 1;
        while(true){
            gra.moveRoad(count);
            while(c <= 1){
                gra.repaint();
                try{
                    Thread.sleep(5);}
                catch(Exception e){
                    System.out.println(e);}
                c++;}
            c = 1;
            count++;
            if(gra.nr_przeciwnikow < 4 && count % 200 == 0){
                gra.przeciwnicy_png[gra.nr_przeciwnikow] = "images/auto_"+((int)((Math.random()*100)%3)+1)+".png";
                gra.px[gra.nr_przeciwnikow] = 499;
                int p = (int)(Math.random()*100)%4;
                if(p == 0){
                    p = 250;}
                else if(p == 1){
                    p = 300;}
                else if(p == 2){
                    p = 185;}
                else{
                    p = 130;}
                gra.py[gra.nr_przeciwnikow] = p;
                gra.predkosc_przeciw[gra.nr_przeciwnikow] = (int)(Math.random()*100)%2 + 2;
                gra.nr_przeciwnikow++;}}
    }
}