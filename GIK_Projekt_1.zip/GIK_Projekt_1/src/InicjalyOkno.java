import javax.swing.*;
import java.awt.*;
public class InicjalyOkno {
    JFrame jFrame;
    Inicjaly i;
    public InicjalyOkno(){
        jFrame = new JFrame();
        Container c = jFrame.getContentPane();
        c.setLayout(new BorderLayout());
        i = new Inicjaly();
        c.add(i);
        JLabel label1 = new JLabel("");
        // f.add(label1);
        jFrame.setSize(650,600);
        jFrame.setVisible(true);
        jFrame.setLocationRelativeTo(null);
        jFrame.setResizable(false);
        //jFrame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
    }
    public static void main(String args[ ]){
        InicjalyOkno o = new InicjalyOkno();
    }
}