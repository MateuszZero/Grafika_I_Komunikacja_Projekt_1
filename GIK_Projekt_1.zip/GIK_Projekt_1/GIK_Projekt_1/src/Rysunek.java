import java.awt.Color;
import java.awt.EventQueue;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.RenderingHints;
import java.awt.BasicStroke;
import javax.swing.JFrame;
import javax.swing.JPanel;
import java.awt.geom.GeneralPath;
class Surface extends JPanel {
    private final double points1[][] = {
            { 0, 85 }, { 125, 5 }, { 250, 85 },
    };
    private final double points2[][] = {
            { 70, 200 }, { 10, 200 }, { 40, 150 }, { 20, 150 },
            { 50, 100 }, { 30, 100 },
            { 70, 50 },
            { 110, 100 },  { 90, 100 }, { 120, 150 }, { 100, 150 },
            { 130, 200 },
    };
    private final double points3[][] = {
            { 90, 220 }, { 30, 220 }, { 60, 170 }, { 40, 170 },
            { 70, 120 }, { 50, 120 },
            { 90, 70 },
            { 130, 120 },  { 110, 120 }, { 140, 170 }, { 120, 170 },
            { 150, 220 },
    };
    private void doDrawing(Graphics g) {
        Graphics2D g2d = (Graphics2D) g;
        RenderingHints rh = new RenderingHints(
                RenderingHints.KEY_ANTIALIASING,
                RenderingHints.VALUE_ANTIALIAS_ON);
        rh.put(RenderingHints.KEY_RENDERING,
                RenderingHints.VALUE_RENDER_QUALITY);
        g2d.setRenderingHints(rh);
        g2d.setPaint(new Color(150, 150, 250));
        g2d.fillRect(0, 0, 770, 550);
        g2d.setPaint(new Color(50, 80, 50));
        g2d.fillRect(0, 370, 770, 150);
        g2d.setPaint(new Color(50, 150, 50));
        g2d.fillRect(0, 400, 770, 150);
        g2d.setPaint(new Color(130, 130, 155));
        g2d.fillOval(320, 150, 30, 30);
        g2d.fillOval(335, 125, 60, 45);
        g2d.fillOval(350, 100, 90, 60);
        g2d.setPaint(new Color(250, 150, 150));
        g2d.fillRect(180, 250, 200, 160);
        g2d.fillRect(320, 170, 30, 80);
        g2d.setPaint(new Color(230, 230, 255));
        g2d.fillRect(210, 300, 70, 70);
        g2d.fillOval(70, 65, 60, 70);
        g2d.fillOval(100, 50, 80, 90);
        g2d.fillOval(150, 65, 60, 70);
        g2d.setPaint(new Color(150, 100, 50));
        g2d.fillRect(310, 330, 50, 80);
        g2d.fillRect(530, 360, 15, 80);
        g2d.fillRect(650, 410, 25, 80);
        BasicStroke bs1 = new BasicStroke(8, BasicStroke.CAP_ROUND,
                BasicStroke.JOIN_BEVEL);
        g2d.setStroke(bs1);
        g2d.drawRect(210, 300, 70, 70);
        g2d.drawLine(210, 335, 280, 335);
        g2d.drawLine(245, 300, 245, 370);
        g2d.setPaint(new Color(230, 230, 0));
        g2d.fillOval(345, 365, 8, 8);
        g2d.fillOval(575, 30, 120, 120);
        g2d.drawLine(505, 90, 765, 90);
        g2d.drawLine(635, 0, 635, 200);
        g2d.drawLine(545, 170, 735, 20);
        g2d.drawLine(545, 20, 735, 170);
        g2d.setPaint(new Color(250, 70, 70));
        g2d.translate(155, 180);
        GeneralPath trojkat = new GeneralPath();
        trojkat.moveTo(points1[0][0], points1[0][1]);
        for (int k = 1; k < points1.length; k++)
            trojkat.lineTo(points1[k][0], points1[k][1]);
        trojkat.closePath();
        g2d.fill(trojkat);
        g2d.setPaint(new Color(50, 150, 150));
        g2d.translate(315, 30);
        GeneralPath drzewo1 = new GeneralPath();
        drzewo1.moveTo(points2[0][0], points2[0][1]);
        for (int k = 1; k < points2.length; k++)
            drzewo1.lineTo(points2[k][0], points2[k][1]);
        drzewo1.closePath();
        g2d.fill(drzewo1);
        g2d.setPaint(new Color(50, 180, 180));
        g2d.translate(100, 30);
        GeneralPath drzewo2 = new GeneralPath();
        drzewo2.moveTo(points3[0][0], points3[0][1]);
        for (int k = 1; k < points3.length; k++)
            drzewo2.lineTo(points3[k][0], points3[k][1]);
        drzewo2.closePath();
        g2d.fill(drzewo2);
        g2d.dispose();
    }
    @Override
    public void paintComponent(Graphics g) {
        super.paintComponent(g);
        doDrawing(g);}
}
public class Rysunek extends JFrame {
    public Rysunek() {
        initUI();}

    private void initUI() {
        add(new Surface());
        setTitle("Rysunek 1 - Domek");
        setSize(770, 550);
        setLocationRelativeTo(null);
        //setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
    }
    public static void main(String[] args) {

        EventQueue.invokeLater(new Runnable() {
            @Override
            public void run() {
                Rysunek ex = new Rysunek();
                ex.setResizable(false);
                ex.setVisible(true);
            }
        });
    }
}